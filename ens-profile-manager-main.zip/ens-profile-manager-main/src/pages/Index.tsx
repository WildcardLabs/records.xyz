
import ENSRecordsManager from "@/components/ENSRecordsManager";

const Index = () => {
  return (
    <div className="min-h-screen bg-[#1A1F2C]">
      <ENSRecordsManager />
    </div>
  );
};

export default Index;

