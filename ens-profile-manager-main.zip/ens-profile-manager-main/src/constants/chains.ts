
export const chainLogos = {
  mainnet: "626dbac5-49c0-425d-8996-4213b368d104.png",
  optimism: "d340be2e-c06a-4ac9-b180-4eedc1439f4f.png",
  base: "704c1ede-df6b-4911-af43-2d274d033df6.png",
  arbitrum: "ecaff6c4-37dd-4440-b585-dcf98a2440cf.png",
  linea: "b871bebc-5864-440b-b642-101a2728678f.png",
  polygon: "70e574c2-77c3-4ced-a446-d98951501fb1.png"
} as const;
